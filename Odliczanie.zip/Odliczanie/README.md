# Odliczanie dni

Prosta aplikacja na Androida (Java, bez zewnętrznych bibliotek) do odliczania dni do wydarzeń.

- lista wielu wydarzeń, posortowana od najbliższego,
- dodawanie, edycja i usuwanie (dotknij wydarzenia),
- "Dziś!" w dniu wydarzenia, a po terminie liczba dni, które minęły,
- dane zapisują się na telefonie, aplikacja nie wymaga żadnych uprawnień.

Wymagania: Android 8.0 (API 26) lub nowszy.

## Jak dostać plik APK

### Opcja A: GitHub (bez instalowania czegokolwiek)
1. Załóż puste repozytorium na github.com i wgraj do niego zawartość tego folderu
   (przycisk "Add file" -> "Upload files", razem z ukrytym folderem `.github`).
2. Wejdź w zakładkę **Actions** -> workflow **Build APK** (uruchomi się sam po wgraniu,
   albo kliknij "Run workflow").
3. Po ok. 2-3 minutach otwórz zakończony przebieg i pobierz artefakt **Odliczanie-apk**
   (w środku jest `app-debug.apk`).

### Opcja B: Android Studio
Otwórz ten folder w Android Studio, poczekaj na synchronizację i wybierz
**Build -> Build APK(s)**. Plik pojawi się w `app/build/outputs/apk/debug/`.

## Instalacja na telefonie
Skopiuj `app-debug.apk` na telefon, otwórz go i zezwól na instalację z tego źródła
(Ustawienia -> Bezpieczeństwo -> Instalowanie nieznanych aplikacji).
