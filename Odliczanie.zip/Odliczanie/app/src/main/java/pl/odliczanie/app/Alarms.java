package pl.odliczanie.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

/** Planowanie alarmów dla wydarzeń oraz wibracja przy końcu odliczania. */
final class Alarms {

    static final String CHANNEL_ID = "odliczanie_koniec";
    static final String ACTION = "pl.odliczanie.app.ALARM";

    // Te same wartości, których używa MainActivity do zapisu wydarzeń.
    private static final String PREFS = "odliczanie";
    private static final String KEY = "events";

    private static final long[] VIBRATION_PATTERN = {0, 800, 400, 800, 400, 800, 400, 1200};

    private Alarms() {
    }

    /** Kanał powiadomień o wysokim priorytecie, widoczny także na ekranie blokady. */
    static void ensureChannel(Context ctx) {
        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        if (nm == null) {
            return;
        }
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Koniec odliczania", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Powiadomienie, gdy czas do wydarzenia dobiegnie końca");
        channel.enableVibration(false); // wibrację uruchamiamy sami, niezależnie od trybu dźwięku
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(channel);
    }

    private static PendingIntent pending(Context ctx, int id, String name) {
        Intent intent = new Intent(ctx, AlarmReceiver.class);
        intent.setAction(ACTION);
        intent.setData(Uri.parse("odliczanie://event/" + id));
        intent.putExtra("id", id);
        intent.putExtra("name", name);
        return PendingIntent.getBroadcast(ctx, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void cancel(Context ctx, int id) {
        AlarmManager am = ctx.getSystemService(AlarmManager.class);
        if (am != null) {
            am.cancel(pending(ctx, id, ""));
        }
    }

    static void schedule(Context ctx, int id, String name, long triggerAtMillis) {
        AlarmManager am = ctx.getSystemService(AlarmManager.class);
        if (am == null) {
            return;
        }
        PendingIntent pi = pending(ctx, id, name);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
            }
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        }
    }

    /** Czyta zapisane wydarzenia i ustawia alarmy dla tych, które jeszcze nie minęły. */
    static void scheduleAll(Context ctx) {
        ensureChannel(ctx);
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long now = System.currentTimeMillis();
        try {
            JSONArray arr = new JSONArray(prefs.getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                int id = o.optInt("id", 0);
                if (id <= 0) {
                    continue;
                }
                String raw = o.has("datetime") ? o.getString("datetime") : o.getString("date");
                LocalDateTime when;
                try {
                    when = LocalDateTime.parse(raw);
                } catch (Exception e) {
                    when = LocalDate.parse(raw).atStartOfDay();
                }
                long trigger = when.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
                if (trigger > now) {
                    schedule(ctx, id, o.optString("name", "Wydarzenie"), trigger);
                } else {
                    cancel(ctx, id);
                }
            }
        } catch (Exception ignored) {
        }
    }

    /** Wibracja traktowana jak alarm, więc działa także w trybie cichym. */
    @SuppressWarnings("deprecation")
    static void vibrate(Context ctx) {
        Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) {
            return;
        }
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        v.vibrate(VibrationEffect.createWaveform(VIBRATION_PATTERN, -1), attrs);
    }

    static void stopVibration(Context ctx) {
        Vibrator v = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) {
            v.cancel();
        }
    }
}
