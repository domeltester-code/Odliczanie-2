package pl.odliczanie.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Ustawia alarmy ponownie po restarcie telefonu, aktualizacji aplikacji lub zmianie strefy czasowej. */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
            Alarms.scheduleAll(context);
        }
    }
}
