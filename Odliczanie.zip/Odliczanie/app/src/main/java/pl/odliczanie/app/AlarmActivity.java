package pl.odliczanie.app;

import android.app.Activity;
import android.app.NotificationManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Ekran "Czas minął!" wyświetlany nad blokadą ekranu. */
public class AlarmActivity extends Activity {

    private int eventId;

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        eventId = getIntent().getIntExtra("id", 0);
        String name = getIntent().getStringExtra("name");
        if (name == null || name.isEmpty()) {
            name = "Wydarzenie";
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.BLACK);
        int pad = dp(24);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("Czas minął!");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 36);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);

        TextView text = new TextView(this);
        text.setText(name);
        text.setTextColor(Color.rgb(100, 181, 246));
        text.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        text.setGravity(Gravity.CENTER);
        text.setPadding(0, dp(12), 0, dp(32));

        Button ok = new Button(this);
        ok.setText("OK");
        ok.setTextColor(Color.WHITE);
        ok.setBackgroundColor(Color.rgb(25, 118, 210));
        ok.setOnClickListener(v -> dismiss());

        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(text, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(ok, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        setContentView(root);
    }

    private void dismiss() {
        Alarms.stopVibration(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null && eventId != 0) {
            nm.cancel(eventId);
        }
        finish();
    }

    @Override
    protected void onDestroy() {
        Alarms.stopVibration(this);
        super.onDestroy();
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }
}
