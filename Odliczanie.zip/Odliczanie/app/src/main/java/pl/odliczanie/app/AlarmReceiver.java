package pl.odliczanie.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Odbiera alarm w chwili końca odliczania: pokazuje powiadomienie i wibruje. */
public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context ctx, Intent intent) {
        int id = intent.getIntExtra("id", 0);
        String name = intent.getStringExtra("name");
        if (name == null || name.isEmpty()) {
            name = "Wydarzenie";
        }

        Alarms.ensureChannel(ctx);

        // Pełnoekranowy ekran "Czas minął!", który włącza wygaszony telefon.
        Intent full = new Intent(ctx, AlarmActivity.class);
        full.putExtra("id", id);
        full.putExtra("name", name);
        full.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent fullPi = PendingIntent.getActivity(ctx, id, full,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Dotknięcie powiadomienia otwiera listę wydarzeń.
        Intent open = new Intent(ctx, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(ctx, id, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification notification = new Notification.Builder(ctx, Alarms.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Czas minął!")
                .setContentText(name)
                .setCategory(Notification.CATEGORY_ALARM)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setShowWhen(true)
                .setAutoCancel(true)
                .setContentIntent(openPi)
                .setFullScreenIntent(fullPi, true)
                .build();

        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        if (nm != null) {
            nm.notify(id, notification);
        }

        Alarms.vibrate(ctx);
    }
}
