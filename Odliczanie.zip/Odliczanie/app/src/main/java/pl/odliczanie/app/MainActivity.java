package pl.odliczanie.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String PREFS = "odliczanie";
    private static final String KEY = "events";
    private static final DateTimeFormatter DATE_FMT =
            DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.forLanguageTag("pl-PL"));

    private static class Item {
        String name;
        LocalDate date;

        Item(String name, LocalDate date) {
            this.name = name;
            this.date = date;
        }

        long daysLeft() {
            return ChronoUnit.DAYS.between(LocalDate.now(), date);
        }
    }

    private final List<Item> items = new ArrayList<>();
    private EventAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Odliczanie dni");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        ListView list = new ListView(this);
        list.setDividerHeight(dp(1));
        adapter = new EventAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> showEditor(items.get(position)));

        TextView empty = new TextView(this);
        empty.setText("Brak wydarzeń.\nDodaj pierwsze przyciskiem poniżej.");
        empty.setGravity(Gravity.CENTER);
        empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        empty.setTextColor(Color.GRAY);
        list.setEmptyView(empty);

        FrameHolder holder = new FrameHolder(this, list, empty);

        Button add = new Button(this);
        add.setText("+ Dodaj wydarzenie");
        add.setOnClickListener(v -> showEditor(null));

        root.addView(holder, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout.LayoutParams addParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        addParams.setMargins(dp(16), dp(8), dp(16), dp(16));
        root.addView(add, addParams);

        setContentView(root);
        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Licznik dni zmienia się o północy, więc odświeżamy przy powrocie do aplikacji.
        sortAndRefresh();
    }

    /** Prosty kontener, który pokazuje listę albo komunikat o braku wydarzeń. */
    private static class FrameHolder extends android.widget.FrameLayout {
        FrameHolder(Activity a, ListView list, TextView empty) {
            super(a);
            addView(list, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
            addView(empty, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }
    }

    private void showEditor(final Item existing) {
        final LocalDate[] chosen = {
                existing != null ? existing.date : LocalDate.now().plusDays(1)
        };

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        final EditText nameInput = new EditText(this);
        nameInput.setHint("Nazwa wydarzenia");
        nameInput.setSingleLine(true);
        if (existing != null) {
            nameInput.setText(existing.name);
        }

        final Button dateBtn = new Button(this);
        dateBtn.setText(DATE_FMT.format(chosen[0]));
        dateBtn.setOnClickListener(v -> {
            LocalDate cur = chosen[0];
            new DatePickerDialog(this, (picker, year, month, day) -> {
                chosen[0] = LocalDate.of(year, month + 1, day);
                dateBtn.setText(DATE_FMT.format(chosen[0]));
            }, cur.getYear(), cur.getMonthValue() - 1, cur.getDayOfMonth()).show();
        });

        box.addView(nameInput);
        box.addView(dateBtn);

        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "Nowe wydarzenie" : "Edytuj wydarzenie")
                .setView(box)
                .setPositiveButton("Zapisz", (dialog, which) -> {
                    String name = nameInput.getText().toString().trim();
                    if (name.isEmpty()) {
                        name = "Wydarzenie";
                    }
                    if (existing == null) {
                        items.add(new Item(name, chosen[0]));
                    } else {
                        existing.name = name;
                        existing.date = chosen[0];
                    }
                    save();
                    sortAndRefresh();
                })
                .setNegativeButton("Anuluj", null);

        if (existing != null) {
            builder.setNeutralButton("Usuń", (dialog, which) -> {
                items.remove(existing);
                save();
                sortAndRefresh();
            });
        }
        builder.show();
    }

    private void sortAndRefresh() {
        Collections.sort(items, new Comparator<Item>() {
            @Override
            public int compare(Item a, Item b) {
                long da = a.daysLeft();
                long db = b.daysLeft();
                boolean pastA = da < 0;
                boolean pastB = db < 0;
                if (pastA != pastB) {
                    return pastA ? 1 : -1; // nadchodzące przed minionymi
                }
                return pastA ? Long.compare(db, da) : Long.compare(da, db);
            }
        });
        adapter.notifyDataSetChanged();
    }

    private void load() {
        items.clear();
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String json = prefs.getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                items.add(new Item(o.getString("name"), LocalDate.parse(o.getString("date"))));
            }
        } catch (Exception ignored) {
            items.clear();
        }
        sortAndRefresh();
    }

    private void save() {
        JSONArray arr = new JSONArray();
        try {
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("name", it.name);
                o.put("date", it.date.toString());
                arr.put(o);
            }
        } catch (Exception ignored) {
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply();
    }

    private static String dayWord(long n) {
        return n == 1 ? "dzień" : "dni";
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private class EventAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            Item item = items.get(position);
            long days = item.daysLeft();

            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(16), dp(14), dp(16), dp(14));

            LinearLayout left = new LinearLayout(MainActivity.this);
            left.setOrientation(LinearLayout.VERTICAL);

            TextView name = new TextView(MainActivity.this);
            name.setText(item.name);
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            name.setTypeface(Typeface.DEFAULT_BOLD);

            TextView date = new TextView(MainActivity.this);
            date.setText(DATE_FMT.format(item.date));
            date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            date.setTextColor(Color.GRAY);

            left.addView(name);
            left.addView(date);

            LinearLayout right = new LinearLayout(MainActivity.this);
            right.setOrientation(LinearLayout.VERTICAL);
            right.setGravity(Gravity.END);

            TextView big = new TextView(MainActivity.this);
            big.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
            big.setTypeface(Typeface.DEFAULT_BOLD);
            big.setGravity(Gravity.END);

            TextView small = new TextView(MainActivity.this);
            small.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            small.setTextColor(Color.GRAY);
            small.setGravity(Gravity.END);

            if (days == 0) {
                big.setText("Dziś!");
                big.setTextColor(Color.rgb(46, 125, 50));
                small.setText("to już dzisiaj");
            } else if (days > 0) {
                big.setText(String.valueOf(days));
                big.setTextColor(Color.rgb(25, 118, 210));
                small.setText(dayWord(days) + " do wydarzenia");
            } else {
                long ago = -days;
                big.setText(String.valueOf(ago));
                big.setTextColor(Color.GRAY);
                small.setText(dayWord(ago) + " temu");
            }

            right.addView(big);
            right.addView(small);

            row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(right, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            return row;
        }
    }
}
