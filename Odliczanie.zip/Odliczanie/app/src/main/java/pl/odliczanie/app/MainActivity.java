package pl.odliczanie.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String PREFS = "odliczanie";
    private static final String KEY = "events";

    private static final Locale PL = Locale.forLanguageTag("pl-PL");
    private static final DateTimeFormatter DATE_FMT =
            DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", PL);
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");

    private static final int BG = Color.BLACK;
    private static final int TEXT = Color.WHITE;
    private static final int MUTED = Color.rgb(150, 150, 150);
    private static final int BLUE = Color.rgb(100, 181, 246);
    private static final int GREEN = Color.rgb(129, 199, 132);

    private static class Item {
        String name;
        LocalDateTime when;
        long created; // chwila dodania wydarzenia (sekundy epoki), początek paska
        int id;       // stały identyfikator, potrzebny do alarmu i powiadomienia

        Item(String name, LocalDateTime when, long created, int id) {
            this.name = name;
            this.when = when;
            this.created = created;
            this.id = id;
        }

        private long targetEpoch() {
            return when.atZone(ZoneId.systemDefault()).toEpochSecond();
        }

        /** Sekundy do wydarzenia (ujemne, jeśli już minęło), liczone względem podanej chwili. */
        long secondsLeft(long nowEpochSecond) {
            return targetEpoch() - nowEpochSecond;
        }

        /** Jaka część czasu od dodania do terminu jeszcze została (1 = cały, 0 = nic). */
        float fractionLeft(long nowEpochSecond) {
            long target = targetEpoch();
            long left = target - nowEpochSecond;
            long total = target - created;
            if (left <= 0) {
                return 0f;
            }
            if (total <= 0) {
                return 1f;
            }
            return Math.min(1f, (float) left / (float) total);
        }
    }

    private static class Holder {
        TextView name;
        TextView when;
        TextView caption;
        BarView bar;
        final TextView[] num = new TextView[4];
        final TextView[] lab = new TextView[4];
    }

    private final List<Item> items = new ArrayList<>();
    private EventAdapter adapter;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            sortAndRefresh();
            long delay = 1000 - (System.currentTimeMillis() % 1000);
            handler.postDelayed(this, delay);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        TextView title = new TextView(this);
        title.setText("Odliczanie");
        title.setTextColor(TEXT);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(16), dp(20), dp(16), dp(12));

        ListView list = new ListView(this);
        list.setBackgroundColor(BG);
        list.setDivider(new ColorDrawable(Color.rgb(34, 34, 34)));
        list.setDividerHeight(dp(1));
        adapter = new EventAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> showEditor(items.get(position)));

        TextView empty = new TextView(this);
        empty.setText("Brak wydarzeń.\nDodaj pierwsze przyciskiem poniżej.");
        empty.setGravity(Gravity.CENTER);
        empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        empty.setTextColor(MUTED);
        list.setEmptyView(empty);

        FrameLayout holder = new FrameLayout(this);
        holder.addView(list, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        holder.addView(empty, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        Button add = new Button(this);
        add.setText("+ Dodaj wydarzenie");
        add.setTextColor(Color.WHITE);
        add.setBackgroundColor(Color.rgb(25, 118, 210));
        add.setOnClickListener(v -> showEditor(null));

        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(holder, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout.LayoutParams addParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        addParams.setMargins(dp(16), dp(8), dp(16), dp(16));
        root.addView(add, addParams);

        setContentView(root);
        Alarms.ensureChannel(this);
        load();
        askForPermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    private void showEditor(final Item existing) {
        final LocalDateTime[] chosen = {
                existing != null
                        ? existing.when
                        : LocalDateTime.of(LocalDate.now().plusDays(1), LocalTime.of(12, 0))
        };

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);

        final EditText nameInput = new EditText(this);
        nameInput.setHint("Nazwa wydarzenia");
        nameInput.setSingleLine(true);
        if (existing != null) {
            nameInput.setText(existing.name);
        }

        final Button dateBtn = new Button(this);
        dateBtn.setText(DATE_FMT.format(chosen[0]));
        dateBtn.setOnClickListener(v -> {
            LocalDateTime cur = chosen[0];
            new DatePickerDialog(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK,
                    (picker, year, month, day) -> {
                        chosen[0] = LocalDateTime.of(
                                LocalDate.of(year, month + 1, day), chosen[0].toLocalTime());
                        dateBtn.setText(DATE_FMT.format(chosen[0]));
                    },
                    cur.getYear(), cur.getMonthValue() - 1, cur.getDayOfMonth()).show();
        });

        final Button timeBtn = new Button(this);
        timeBtn.setText(TIME_FMT.format(chosen[0]));
        timeBtn.setOnClickListener(v -> {
            LocalDateTime cur = chosen[0];
            new TimePickerDialog(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK,
                    (picker, hour, minute) -> {
                        chosen[0] = LocalDateTime.of(
                                chosen[0].toLocalDate(), LocalTime.of(hour, minute));
                        timeBtn.setText(TIME_FMT.format(chosen[0]));
                    },
                    cur.getHour(), cur.getMinute(), true).show();
        });

        box.addView(nameInput);
        box.addView(dateBtn);
        box.addView(timeBtn);

        AlertDialog.Builder builder = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(existing == null ? "Nowe wydarzenie" : "Edytuj wydarzenie")
                .setView(box)
                .setPositiveButton("Zapisz", (dialog, which) -> {
                    String name = nameInput.getText().toString().trim();
                    if (name.isEmpty()) {
                        name = "Wydarzenie";
                    }
                    if (existing == null) {
                        items.add(new Item(name, chosen[0], Instant.now().getEpochSecond(), newId()));
                    } else {
                        existing.name = name;
                        if (!chosen[0].equals(existing.when)) {
                            // Zmieniony termin: pasek liczymy od nowa.
                            existing.created = Instant.now().getEpochSecond();
                        }
                        existing.when = chosen[0];
                    }
                    save();
                    sortAndRefresh();
                })
                .setNegativeButton("Anuluj", null);

        if (existing != null) {
            builder.setNeutralButton("Usuń", (dialog, which) -> {
                Alarms.cancel(this, existing.id);
                items.remove(existing);
                save();
                sortAndRefresh();
            });
        }
        builder.show();
    }

    private void sortAndRefresh() {
        final long now = Instant.now().getEpochSecond();
        Collections.sort(items, new Comparator<Item>() {
            @Override
            public int compare(Item a, Item b) {
                long la = a.secondsLeft(now);
                long lb = b.secondsLeft(now);
                boolean pastA = la < 0;
                boolean pastB = lb < 0;
                if (pastA != pastB) {
                    return pastA ? 1 : -1; // nadchodzące przed minionymi
                }
                return pastA ? Long.compare(lb, la) : Long.compare(la, lb);
            }
        });
        adapter.notifyDataSetChanged();
    }

    private void load() {
        items.clear();
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String json = prefs.getString(KEY, "[]");
        boolean migrated = false;
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                // Starsza wersja zapisywała samą datę pod kluczem "date".
                String raw = o.has("datetime") ? o.getString("datetime") : o.getString("date");
                LocalDateTime when;
                try {
                    when = LocalDateTime.parse(raw);
                } catch (Exception e) {
                    when = LocalDate.parse(raw).atStartOfDay();
                }
                long created = o.optLong("created", 0);
                if (created <= 0) {
                    // Wydarzenie ze starszej wersji: pasek startuje od teraz.
                    created = Instant.now().getEpochSecond();
                    migrated = true;
                }
                int id = o.optInt("id", 0);
                if (id <= 0) {
                    id = newId();
                    migrated = true;
                }
                items.add(new Item(o.getString("name"), when, created, id));
            }
        } catch (Exception ignored) {
            items.clear();
            migrated = false;
        }
        if (migrated) {
            save(); // zapis ustawia też alarmy
        } else {
            Alarms.scheduleAll(this);
        }
        sortAndRefresh();
    }

    private void save() {
        JSONArray arr = new JSONArray();
        try {
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("name", it.name);
                o.put("datetime", it.when.toString());
                o.put("created", it.created);
                o.put("id", it.id);
                arr.put(o);
            }
        } catch (Exception ignored) {
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply();
        Alarms.scheduleAll(this);
    }

    private int newId() {
        java.util.Random random = new java.util.Random();
        int id;
        boolean clash;
        do {
            id = 1 + random.nextInt(Integer.MAX_VALUE - 1);
            clash = false;
            for (Item it : items) {
                if (it.id == id) {
                    clash = true;
                    break;
                }
            }
        } while (clash);
        return id;
    }

    /** Android 13+: zgoda na powiadomienia. Android 14+: zgoda na powiadomienia pełnoekranowe. */
    private void askForPermissions() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1);
            return;
        }
        maybeAskFullScreen();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        maybeAskFullScreen();
    }

    private void maybeAskFullScreen() {
        if (Build.VERSION.SDK_INT < 34) {
            return;
        }
        NotificationManager nm = getSystemService(NotificationManager.class);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (nm == null || nm.canUseFullScreenIntent() || prefs.getBoolean("fsi_asked", false)) {
            return;
        }
        prefs.edit().putBoolean("fsi_asked", true).apply();
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle("Powiadomienie na ekranie blokady")
                .setMessage("Aby telefon włączył ekran, gdy czas się skończy, zezwól aplikacji "
                        + "na powiadomienia pełnoekranowe.")
                .setPositiveButton("Ustawienia", (dialog, which) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception ignored) {
                    }
                })
                .setNegativeButton("Później", null)
                .show();
    }

    private int dp(int v) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    private View buildRow() {
        Holder h = new Holder();

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(16), dp(14), dp(16), dp(14));
        row.setBackgroundColor(BG);

        h.name = new TextView(this);
        h.name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        h.name.setTypeface(Typeface.DEFAULT_BOLD);
        h.name.setTextColor(TEXT);

        h.when = new TextView(this);
        h.when.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        h.when.setTextColor(MUTED);

        LinearLayout counter = new LinearLayout(this);
        counter.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 4; i++) {
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);

            h.num[i] = new TextView(this);
            h.num[i].setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
            h.num[i].setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            h.num[i].setGravity(Gravity.CENTER);

            h.lab[i] = new TextView(this);
            h.lab[i].setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            h.lab[i].setTextColor(MUTED);
            h.lab[i].setGravity(Gravity.CENTER);

            cell.addView(h.num[i]);
            cell.addView(h.lab[i]);
            counter.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }

        h.caption = new TextView(this);
        h.caption.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        h.caption.setTextColor(MUTED);
        h.caption.setGravity(Gravity.CENTER);

        row.addView(h.name);
        row.addView(h.when);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(10);
        row.addView(counter, cp);

        h.bar = new BarView(this);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
        bp.topMargin = dp(10);
        row.addView(h.bar, bp);
        row.addView(h.caption, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        row.setTag(h);
        return row;
    }

    /** Pasek pokazujący, jaka część czasu do wydarzenia jeszcze została. */
    private static class BarView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private float fraction = 1f;
        private int color = Color.WHITE;

        BarView(Context context) {
            super(context);
        }

        void set(float newFraction, int newColor) {
            if (newFraction != fraction || newColor != color) {
                fraction = newFraction;
                color = newColor;
                invalidate();
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            float r = h / 2f;

            paint.setColor(Color.rgb(40, 40, 40));
            rect.set(0, 0, w, h);
            canvas.drawRoundRect(rect, r, r, paint);

            float filled = w * fraction;
            if (filled > 0f) {
                paint.setColor(color);
                rect.set(0, 0, Math.max(filled, h), h);
                canvas.drawRoundRect(rect, r, r, paint);
            }
        }
    }

    private static String two(long v) {
        return String.format(Locale.ROOT, "%02d", v);
    }

    private class EventAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public Object getItem(int position) {
            return items.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = buildRow();
            }
            Holder h = (Holder) convertView.getTag();
            Item item = items.get(position);

            long now = Instant.now().getEpochSecond();
            long left = item.secondsLeft(now);
            boolean past = left < 0;
            long s = Math.abs(left);
            long days = s / 86400;
            long hours = (s % 86400) / 3600;
            long minutes = (s % 3600) / 60;
            long seconds = s % 60;

            int color = past ? MUTED : (left < 86400 ? GREEN : BLUE);

            h.name.setText(item.name);
            h.when.setText(DATE_FMT.format(item.when) + ", " + TIME_FMT.format(item.when));

            h.num[0].setText(String.valueOf(days));
            h.num[1].setText(two(hours));
            h.num[2].setText(two(minutes));
            h.num[3].setText(two(seconds));
            for (int i = 0; i < 4; i++) {
                h.num[i].setTextColor(color);
            }

            h.lab[0].setText(days == 1 ? "DZIEŃ" : "DNI");
            h.lab[1].setText("GODZ.");
            h.lab[2].setText("MIN");
            h.lab[3].setText("SEK.");

            float fraction = item.fractionLeft(now);
            h.bar.set(fraction, color);
            h.caption.setText(past
                    ? "minęło od wydarzenia"
                    : "pozostało do wydarzenia · " + Math.round(fraction * 100) + "%");
            return convertView;
        }
    }
}
